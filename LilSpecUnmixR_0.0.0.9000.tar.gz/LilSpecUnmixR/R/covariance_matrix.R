covariance_matrix <- function(){


}
